
const base_url = 'http://localhost:9091';

export default base_url;