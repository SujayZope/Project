import React from "react";


const Footer =() =>{
    return(
        <>
        <footer className="bg-light text-center">
            <p>@ 2022 The CarMarket. All Rights Reserved | Terms and Conditions</p>

        </footer>
        </>
    );
};

export default Footer;