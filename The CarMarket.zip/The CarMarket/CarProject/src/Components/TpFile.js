import React from 'react';
import BuyerHome from './BuyerHome'

const TpFile = ()=>{
    return(
        <>
        {/* <BuyerHome /> */}
        <h1>from tp file</h1>
        </>
    )
}

export default TpFile;